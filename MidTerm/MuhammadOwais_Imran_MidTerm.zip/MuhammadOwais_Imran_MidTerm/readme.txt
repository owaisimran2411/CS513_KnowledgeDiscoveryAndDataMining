Name: Muhammad Owais Imran
CWID: 20025554
CS513 (MidTerm Exam)